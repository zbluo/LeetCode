#include "stdafx.h"
#include "systemdesign_ro.h"


systemdesign_ro::systemdesign_ro()
{
}


systemdesign_ro::~systemdesign_ro()
{
}
