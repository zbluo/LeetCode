#include "stdafx.h"
#include "systemdesign_cards.h"


systemdesign_cards::systemdesign_cards()
{
}


systemdesign_cards::~systemdesign_cards()
{
}
