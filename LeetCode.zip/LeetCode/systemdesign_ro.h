#pragma once
class systemdesign_ro
{
public:
	systemdesign_ro();
	~systemdesign_ro();
};


